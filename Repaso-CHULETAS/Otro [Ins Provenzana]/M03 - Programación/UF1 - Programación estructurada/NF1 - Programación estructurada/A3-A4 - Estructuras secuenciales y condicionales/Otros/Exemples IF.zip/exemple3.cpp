/*ejemplo pide dos numeros y me diga cual es mayor o si son iguales*/

#include <stdio.h>

main(){
	int num1,num2;
	
	//pido los numeros
	printf("dame numero 1: ");
	scanf("%i",&num1);
	printf("dame numero 2: ");
	scanf("%i",&num2);
	
	//comparo
	if(num1>num2){
		printf("El numero 1 es mayor que el 2");
	}
	else{
		if(num2>num1){
			printf("El numero dos es mayor");
		}
		else{
			printf("Los numeros son iguales");
		}
	}

}

















