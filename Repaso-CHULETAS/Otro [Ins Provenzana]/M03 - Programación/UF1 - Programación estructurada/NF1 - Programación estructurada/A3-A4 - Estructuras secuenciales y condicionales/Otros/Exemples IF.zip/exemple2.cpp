/*ejemplo pide dos numeros y me diga si son iguales*/

#include <stdio.h>

main(){
	int num1,num2;
	
	//pido los numeros
	printf("dame numero 1: ");
	scanf("%i",&num1);
	printf("dame numero 2: ");
	scanf("%i",&num2);
	
	//comparo
	if(num1==num2){ //con dos == para la comparacion
		printf("Son iguales");
		printf("\n%i y %i",num1,num2);
	}
	else{
		printf("son diferentes");
	}
}

















