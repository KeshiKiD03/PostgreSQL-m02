/*ejemplo if*/

#include <stdio.h>

main(){
	int edad,any;
	
	printf("Dime la edad que tienes: ");
	scanf("%i",&edad);
	
	//estructura secuencial
	
	if(edad>=18){
		printf("Eres mayor de edad");
	}
	else{
		printf("Eres menor de edad");
	}
}

















