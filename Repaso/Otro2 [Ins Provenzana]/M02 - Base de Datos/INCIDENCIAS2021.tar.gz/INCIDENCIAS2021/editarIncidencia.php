<?php
// including the database connection file
include_once("config.php");
 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $tecnic=$_POST['tecnic'];
    $tipus=$_POST['tipus'];
    $prioritat=$_POST['prioritat'];    
    
    // checking empty fields
    /*if(empty($nomDpt) || empty($desc) || empty($email)) {            
        if(empty($nomDpt)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        
        if(empty($desc)) {
            echo "<font color='red'>Age field is empty.</font><br/>";
        }
        
        if(empty($email)) {
            echo "<font color='red'>Email field is empty.</font><br/>";
        }        
    } else {    */
        //updating the table
        $orden= "UPDATE INCIDENCIA SET codiTec='$tecnic',codiTip='$tipus',clasificacio='$prioritat' WHERE codInci=$id";
        echo $orden;
        $result = mysqli_query($mysqli,$orden);
        
        //redirectig to the display page. In our case, it is index.php
        //header("Location: index.php");
   // }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT INCIDENCIA.* , DEPARTAMENT.nom FROM INCIDENCIA JOIN DEPARTAMENT ON INCIDENCIA.codDep=DEPARTAMENT.codDep
WHERE codInci=$id");
 
while($res = mysqli_fetch_array($result))
{
    $nomDpt = $res['nom'];
    $desc = $res['descripcio'];
    $codiTec = $res['codiTec'];
    $codiTip = $res['codiTip'];
    $clasificacio = $res['clasificacio'];
    
}
?>
<html>
<head>    
    <title>Editar incidencia</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="post" action="editarIncidencia.php">
        <table border="0">
            <tr> 
                <td>Departament</td>
                <td><input type="text" name="nomDpt" value="<?php echo $nomDpt;?>" disabled></td>
            </tr>
            <tr> 
                <td>Descripcio</td>
                <td><textarea type="text" name="desc"disabled ><?php echo $desc;?></textarea></td>
            </tr>
            <tr> 
                <td>Técnic</td>
                <td>
                <input type="text" name="tecnic" value="<?php echo $codiTec;?>">
                </td>
            </tr>
            <tr> 
                <td>Tipus</td>
                <td>
                <input type="text" name="tipus" value="<?php echo $codiTip;?>">
                </td>
            </tr>
            <tr> 
                <td>Prioritat</td>
                <td>
                <input type="text" name="prioritat" value="<?php echo $clasificacio;?>">
                </td>
            </tr>
           
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Actualizar"></td>
            </tr>
        </table>
    </form>
</body>
</html>