<?php include("header.php"); ?>
	

<body>
	<a href="index.php">&nbsp&nbspHome</a>
	<br/><br/>

	<form action="consultaIncidencia2.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>&nbsp&nbspCódigo de la &nbsp&nbspincidencia</td>
				<td><input type="text" name="id"></td>
			</tr>
			
			
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Consulta Incidencia"></td>
			</tr>
		</table>
	</form>


<?php include("footer.php"); ?>
