<html>
<head>
    <title>Add Data</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
 
    <form action="afegirIncidencia.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>Departament</td>
                <td>

                <?php
                //including the database connection file
                include_once("config.php");
                
                //fetching data in descending order (lastest entry first)
                //$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
                $result = mysqli_query($mysqli, "SELECT * FROM DEPARTAMENT"); // using mysqli_query instead
                ?>
                <select name="departament" >
                    <?php                     
                        while($res = mysqli_fetch_array($result)) {                                 
                            echo "<option value=".$res['codDep'].">".$res['nom']."</option>";                             
                        }
                    ?>                    
                </select>
                
                
                
                </td>
            </tr>
            <tr> 
                <td>Descripcio</td>
                <td>
                    <textarea name="descripcio" rows="4" cols="50"></textarea>
                </td>
            </tr>
        
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Afegir incidencia"></td>
            </tr>
        </table>
    </form>
</body>
</html>