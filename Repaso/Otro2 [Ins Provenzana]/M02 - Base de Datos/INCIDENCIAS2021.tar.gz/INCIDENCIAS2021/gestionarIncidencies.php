<?php
//including the database connection file
include_once("config.php");
 
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT INCIDENCIA.* , DEPARTAMENT.nom , TECNIC.nombre FROM INCIDENCIA JOIN DEPARTAMENT ON INCIDENCIA.codDep=DEPARTAMENT.codDep
LEFT JOIN TECNIC ON INCIDENCIA.codiTec=TECNIC.codiTec
ORDER BY INCIDENCIA.codInci "); // using mysqli_query instead
?>
 
<html>
<head>
<meta charset="UTF-8">   
    <title>Homepage</title>
</head>
 
<body>
    <a href="afegirIncidencia_previo.php">Afegir dades</a><br/><br/>
 
    <table width='80%' border=0>
        <tr bgcolor='#CCCCCC'>
            <td>Data</td>
            <td>Descripció</td>
            <td>Prioritat</td>
            <td>Departament</td>
            <td>Tècnic</td>
            <td>Update</td>
        </tr>
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['dataIni']."</td>";
            echo "<td>".$res['descripcio']."</td>";
            echo "<td>".$res['clasificacio']."</td>";    
            echo "<td>".$res['nom']."</td>"; 
            echo "<td>".$res['nombre']."</td>"; 
            echo "<td><a href=\"editarIncidencia.php?id=$res[codInci]\">Editar</a> | <a href=\"borrar.php?id=$res[codInci]\" onClick=\"return confirm('Estas segur?')\">Borrar</a></td>";        
        }
        ?>
    </table>
</body>
</html>
