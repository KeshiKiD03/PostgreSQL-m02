<?php include("header.php"); ?>
<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT INCIDENCIA.id, TECNIC.nom as tecnic, INCIDENCIA.descripcio, INCIDENCIA.data, INCIDENCIA.prioritat, DEPARTAMENT.nom FROM INCIDENCIA LEFT JOIN DEPARTAMENT ON INCIDENCIA.departament=DEPARTAMENT.id LEFT JOIN TECNIC ON INCIDENCIA.tecnic=TECNIC.id WHERE INCIDENCIA.id=".$_POST['id']); // using mysqli_query instead
?>

<html>
<head>	
	<title>Datos de la incidencia</title>
</head>

<body>
	<h1>Dades de la incidència</h1>
	<table class="table">

<tr bgcolor='#CCCCCC'>
	<td>ID</td>
	<td>Descripcio</td>
	<td>Departament</td>
	<td>Data</td>
	<td>Tècnic</td>
	<td>Prioritat</td>
	<td>Accions</td>
</tr>
<?php 

while($res = mysqli_fetch_array($result)) { 		
	if($res['prioritat']=="ALTA") echo("<tr class='bg-danger'>");
	else echo("<tr>");
	echo "<td>".$res['id']."</td>";
	echo "<td>".$res['descripcio']."</td>";
	echo "<td>".$res['nom']."</td>";	
	echo "<td>".$res['data']."</td>";	
	echo "<td>".$res['tecnic']."</td>";	
	echo "<td>".$res['prioritat']."</td>";	
	echo "<td><a href=\"consultaIncidencia.php?id=$res[id]\">Editar</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Estas segur qeu vols eliminar la incidència')\">Eliminar</a></td>";		
}
?>
</table>
	




<?php include("footer.php"); ?>