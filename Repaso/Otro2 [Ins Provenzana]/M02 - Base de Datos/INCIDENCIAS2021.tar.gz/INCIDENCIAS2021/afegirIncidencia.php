<?php include("header.php"); ?>
<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['Submit'])) {	
	$departament = mysqli_real_escape_string($mysqli, $_POST['departament']);
	$descripcio = mysqli_real_escape_string($mysqli, $_POST['descripcio']);
		
	// checking empty fields
	if(empty($departament) || empty($descripcio) ) {
				
		if(empty($departament)) {
			echo "<font color='red'>No pots deixar buit el nom del departament.</font><br/>";
		}
		
		if(empty($descripcio)) {
			echo "<font color='red'>Has de posar alguna descripcio</font><br/>";
		}
		
	
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO INCIDENCIA(descripcio,departament) VALUES('$descripcio',1)");		
		echo "<font color='green'>Incidència registrada correctament. El teu codi es";

		$result2 = mysqli_query($mysqli, "SELECT MAX(codInci) AS elid FROM INCIDENCIA");
		while($res = mysqli_fetch_array($result2)) { 							
			//display success message					
			echo "<h2>".$res['elid']."</h2>";
			echo "<br/><a href='index.php'>Menu</a>";
		}
	}
}
?>
<?php include("footer.php"); ?>
</body>
</html>