<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include 'header.php'; ?>
</head>
<body>


<table class="table">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Usuaris</th>
      <th scope="col">Tècnics</th>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
      <td><a href="afegirIncidencia_previo.php">Crear Incidencia</th>
      <td>Registrar actuacio</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td><a href="consultaIncidencia.php">Consultar Incidencia</td>
      <td>Gestionar Incidencies</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></th>
      <td>Registrar Actuacio</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></th>
      <td>Informe de tecnics</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></th>
      <td>Consum per departements</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    
  </tbody>
</table>

    <?php include 'footer.php'; ?>
</body>
</html>
